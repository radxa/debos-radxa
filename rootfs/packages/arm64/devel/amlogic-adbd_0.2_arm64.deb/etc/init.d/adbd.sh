#!/bin/bash -e
# setup configfs for adbd, usb mass storage and MTP....

modprobe usb_f_fs

ADB_EN=off

make_config_string()
{
	tmp=$CONFIG_STRING
	if [ -n "$CONFIG_STRING" ]; then
		CONFIG_STRING=${tmp}_${1}
	else
		CONFIG_STRING=$1
	fi
}

parameter_init()
{
	while read line
	do
		case "$line" in
			usb_adb_en)
				ADB_EN=on
				make_config_string adb
				;;
		esac
	done < $DIR/.usb_config


	case "$CONFIG_STRING" in
		adb)
			PID=0x0006
			;;
		*)
			PID=0x0019
	esac
}

configfs_init()
{
	mkdir -p /sys/kernel/config/usb_gadget/amlogic -m 0770
	echo 0x1b8e > /sys/kernel/config/usb_gadget/amlogic/idVendor
	echo $PID > /sys/kernel/config/usb_gadget/amlogic/idProduct
	mkdir -p /sys/kernel/config/usb_gadget/amlogic/strings/0x409 -m 0770
	echo "0123456789ABCDEF" > /sys/kernel/config/usb_gadget/amlogic/strings/0x409/serialnumber
	echo "amlogic"  > /sys/kernel/config/usb_gadget/amlogic/strings/0x409/manufacturer
	echo "meson"  > /sys/kernel/config/usb_gadget/amlogic/strings/0x409/product
	mkdir -p /sys/kernel/config/usb_gadget/amlogic/configs/b.1 -m 0770
	mkdir -p /sys/kernel/config/usb_gadget/amlogic/configs/b.1/strings/0x409 -m 0770
	echo 500 > /sys/kernel/config/usb_gadget/amlogic/configs/b.1/MaxPower
	echo \"$CONFIG_STRING\" > /sys/kernel/config/usb_gadget/amlogic/configs/b.1/strings/0x409/configuration
}

function_init()
{
	if [ $ADB_EN = on ];then
		if [ ! -e "/sys/kernel/config/usb_gadget/amlogic/functions/ffs.adb" ] ;
		then
			mkdir -p /sys/kernel/config/usb_gadget/amlogic/functions/ffs.adb
			ln -s /sys/kernel/config/usb_gadget/amlogic/functions/ffs.adb /sys/kernel/config/usb_gadget/amlogic/configs/b.1/ffs.adb
		fi
	fi
}

case "$1" in
start)
	DIR=$(cd `dirname $0`; pwd)
	if [ ! -e "$DIR/.usb_config" ]; then
		echo "$0: Cannot find .usb_config"
		exit 0
	fi

	parameter_init
	if [ -z $CONFIG_STRING ]; then
		echo "$0: no function be selected"
		exit 0
	fi
	configfs_init
	function_init

	if [ $ADB_EN = on ];then
		if [ ! -e "/dev/usb-ffs/adb" ] ;
		then
			mkdir -p /dev/usb-ffs/adb
			mount -o uid=2000,gid=2000 -t functionfs adb /dev/usb-ffs/adb
		fi
		export service_adb_tcp_port=5555
		start-stop-daemon --start --oknodo --pidfile /var/run/adbd.pid --startas /usr/local/bin/adbd --background
		sleep 1
	fi

	UDC=`ls /sys/class/udc/| awk '{print $1}'`
	echo $UDC > /sys/kernel/config/usb_gadget/amlogic/UDC
	;;
stop)
	echo "none" > /sys/kernel/config/usb_gadget/amlogic/UDC
	if [ $ADB_EN = on ];then
		start-stop-daemon --stop --oknodo --pidfile /var/run/adbd.pid --retry 5
	fi
	;;
restart|reload)
	;;
*)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit 0
