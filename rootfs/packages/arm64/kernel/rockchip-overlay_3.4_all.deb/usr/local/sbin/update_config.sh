#!/bin/bash

set -eo pipefail

APPEND="   append "

if [[ -f "/boot/config.txt" ]]; then
    for DTBO in `grep "^dtoverlay=" /boot/config.txt | sed 's/dtoverlay=//g'`
    do
        radxa-add-overlay.py -i ${DTBO}
    done

    for CMDLINE in `grep "^cmdline:" /boot/config.txt | sed 's/cmdline://g'`
    do
        APPEND="$APPEND $CMDLINE"
    done
    sed 's/*append*/$APPEND/' /boot/extlinux/extlinux.conf
fi

echo "Show /boot/config.txt:"
cat /boot/config.txt
ehco " "
echo "Show /boot/extlinux/extlinux.conf:"
cat /boot/extlinux/extlinux.conf
echo " "
