#ifndef __I2C_DEF_H__
#define __I2C_DEF_H__

#include "xf86i2c.h"

#endif
